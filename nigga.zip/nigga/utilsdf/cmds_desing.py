from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from utilsdf.functions import symbol

text_home = """𝙒𝙚𝙡𝙘𝙤𝙢𝙚 »
<code>NIGGA JUST CHECK UR FUCKING CC  AND GET THE FUCK OUT OF HERE.</code>
                  
<a href='tg://user?id={}'>朱 𝙑𝙚𝙧𝙨𝙞𝙤𝙣 </a> -» <code>2.0</code>"""

exit_button = InlineKeyboardButton("𝙀𝙭𝙞𝙩 ⚠️", "exit")

buttons_cmds = InlineKeyboardMarkup(
    [
        [
            InlineKeyboardButton("𝙂𝙖𝙩𝙚𝙨 ♻️", "gates"),
            InlineKeyboardButton("𝙏𝙤𝙤𝙡𝙨 🛠", "tools"),
        ],
        [InlineKeyboardButton("𝘾𝙝𝙖𝙣𝙣𝙚𝙡 💫", url="https://t.me/approvedccbin")],
        [exit_button],
    ]
)

buttons_gates = InlineKeyboardMarkup(
    [
        [
            InlineKeyboardButton("𝘼𝙪𝙩𝙝 ", "auths"),
            InlineKeyboardButton("𝘾𝙝𝙖𝙧𝙜𝙚𝙙 ", "chargeds"),
        ],
        [InlineKeyboardButton("𝙎𝙥𝙚𝙘𝙞𝙖𝙡 ", "specials")],
        [InlineKeyboardButton("𝙍𝙚𝙩𝙪𝙧𝙣 🔄", "home")],
        [exit_button],
    ]
)


# RETURN & EXIT GATES
return_and_exit_gates = InlineKeyboardMarkup(
    [
        [InlineKeyboardButton("𝙍𝙚𝙩𝙪𝙧𝙣 🔄", "gates")],
        [exit_button],
    ]
)

# RETURN HOME & EXIT
return_home_and_exit = InlineKeyboardMarkup(
    [
        [InlineKeyboardButton("𝙍𝙚𝙩𝙪𝙧𝙣 🔄", "home")],
        [exit_button],
    ]
)


# GATES AUTH

text_gates_auth = f"""
𝐀𝐮𝐭𝐡 𝐆𝐚𝐭𝐞𝐰𝐚𝐲𝐬

朱 𝙎𝙚𝙭𝙤 -» Braintree -» Auth 
零 𝘾𝙢𝙙 -» .sexo -» Free 
ᥫ᭡ 𝙎𝙩𝙖𝙩𝙪𝙨 -» On ✅

朱 𝙋𝙪𝙨𝙨𝙮 -» Braintree -» Auth 
零 𝘾𝙢𝙙 -» .ps -» Premium 
ᥫ᭡ 𝙎𝙩𝙖𝙩𝙪𝙨 -» On ✅

零 𝕃𝕪𝕟𝕩 -» Stripe[Ccn] -» Auth
零 𝘾𝙢𝙙 -» .lynx -» Free
ᥫ᭡ 𝙎𝙩𝙖𝙩𝙪𝙨 -» On ✅

朱 𝘼𝙠𝙩𝙯 -» Stripe -» Auth
零 𝘾𝙢𝙙 -» .ak -» Premium
ᥫ᭡ 𝙎𝙩𝙖𝙩𝙪𝙨 -» On ✅

零 𝙋𝙞𝙘𝙘𝙤𝙡𝙤 -» Stripe[Ccn] -» Auth
零 𝘾𝙢𝙙 -» .pi -» Free
ᥫ᭡ 𝙎𝙩𝙖𝙩𝙪𝙨 -» On ✅

零 𝘼𝙨𝙩𝙝𝙖𝙧𝙤𝙩𝙝 -» Stripe[Ccn] -» Auth
零 𝘾𝙢𝙙 -» .at -» Free
ᥫ᭡ 𝙎𝙩𝙖𝙩𝙪𝙨 -» On ✅

𝘿𝙚𝙫: @rundilundlegamera

"""

buttons_auth_page_1 = InlineKeyboardMarkup(
    [
        [InlineKeyboardButton("𝙍𝙚𝙩𝙪𝙧𝙣 🔄", "home")],
    ]
)

# GATES CHARGED

text_gates_charged = f"""
𝐂𝐡𝐚𝐫𝐠𝐞𝐝 𝐆𝐚𝐭𝐞𝐰𝐚𝐲𝐬

[娘] 𝘕𝘢𝘮𝘦: Paypal
[娘] 𝘛𝘺𝘱𝘦: Free
[娘] 𝘊𝘰𝘮𝘮𝘢𝘯𝘥: /pp card|month|year|cvv
[娘] 𝘚𝘵𝘢𝘵𝘶𝘴: On ✅
[娘] 𝘎𝘢𝘵𝘦𝘸𝘢𝘺: Paypal $0.01

[娘] 𝘕𝘢𝘮𝘦: Paypal
[娘] 𝘛𝘺𝘱𝘦: Free
[娘] 𝘊𝘰𝘮𝘮𝘢𝘯𝘥: /ppa card|month|year|cvv
[娘] 𝘚𝘵𝘢𝘵𝘶𝘴: On ✅
[娘] 𝘎𝘢𝘵𝘦𝘸𝘢𝘺: Paypal $1

[娘] 𝘕𝘢𝘮𝘦: Ass
[娘] 𝘛𝘺𝘱𝘦: Premium
[娘] 𝘊𝘰𝘮𝘮𝘢𝘯𝘥: /ass card|month|year|cvv
[娘] 𝘚𝘵𝘢𝘵𝘶𝘴: On ✅
[娘] 𝘎𝘢𝘵𝘦𝘸𝘢𝘺: fatZebra VBV $4

[娘] 𝘕𝘢𝘮𝘦: Ghoul
[娘] 𝘛𝘺𝘱𝘦: Premium
[娘] 𝘊𝘰𝘮𝘮𝘢𝘯𝘥: /gh card|month|year|cvv
[娘] 𝘚𝘵𝘢𝘵𝘶𝘴: On ✅
[娘] 𝘎𝘢𝘵𝘦𝘸𝘢𝘺: SquareUp $10

[娘] 𝘕𝘢𝘮𝘦: Brenda
[娘] 𝘛𝘺𝘱𝘦: Premium
[娘] 𝘊𝘰𝘮𝘮𝘢𝘯𝘥: /br card|month|year|cvv
[娘] 𝘚𝘵𝘢𝘵𝘶𝘴: On ✅
[娘] 𝘎𝘢𝘵𝘦𝘸𝘢𝘺: Onrally + Braintree $28.99

[娘] 𝘕𝘢𝘮𝘦: Mora
[娘] 𝘛𝘺𝘱𝘦: Premium
[娘] 𝘊𝘰𝘮𝘮𝘢𝘯𝘥: /mo card|month|year|cvv
[娘] 𝘚𝘵𝘢𝘵𝘶𝘴: On ✅
[娘] 𝘎𝘢𝘵𝘦𝘸𝘢𝘺: Shopify + Braintree $25

[娘] 𝘕𝘢𝘮𝘦: Kyusuke
[娘] 𝘛𝘺𝘱𝘦: Premium
[娘] 𝘊𝘰𝘮𝘮𝘢𝘯𝘥: /ky card|month|year|cvv
[娘] 𝘚𝘵𝘢𝘵𝘶𝘴: On ✅
[娘] 𝘎𝘢𝘵𝘦𝘸𝘢𝘺: Shopify + Cybersource $15

[娘] 𝘕𝘢𝘮𝘦: Hidan
[娘] 𝘛𝘺𝘱𝘦: Free
[娘] 𝘊𝘰𝘮𝘮𝘢𝘯𝘥: /hi card|month|year|cvv
[娘] 𝘚𝘵𝘢𝘵𝘶𝘴: On ✅
[娘] 𝘎𝘢𝘵𝘦𝘸𝘢𝘺: Shopify + Braintree $58

𝘿𝙚𝙫: @rundilundlegamera"""
buttons_charged_page_1 = InlineKeyboardMarkup(
    [
        [InlineKeyboardButton("𝙍𝙚𝙩𝙪𝙧𝙣 🔄", "home")],
    ]
)

# GATES SPECIALS
text_gates_especials = f"""𝐒𝐩𝐞𝐜𝐢𝐚𝐥 𝐆𝐚𝐭𝐞𝐰𝐚𝐲𝐬

[娘] 𝘕𝘢𝘮𝘦: Orochimaru
[娘] 𝘛𝘺𝘱𝘦: Premium
[娘] 𝘊𝘰𝘮𝘮𝘢𝘯𝘥: /or card|month|year|cvv
[娘] 𝘚𝘵𝘢𝘵𝘶𝘴: On ✅
[娘] 𝘎𝘢𝘵𝘦𝘸𝘢𝘺: Stripe CCN $1

[娘] 𝘕𝘢𝘮𝘦: Boruto
[娘] 𝘛𝘺𝘱𝘦: Premium
[娘] 𝘊𝘰𝘮𝘮𝘢𝘯𝘥: /bo card|month|year|cvv
[娘] 𝘚𝘵𝘢𝘵𝘶𝘴: On ✅
[娘] 𝘎𝘢𝘵𝘦𝘸𝘢𝘺: Stripe CCN $26.29

[娘] 𝘕𝘢𝘮𝘦: Harley Quinn
[娘] 𝘛𝘺𝘱𝘦: Premium
[娘] 𝘊𝘰𝘮𝘮𝘢𝘯𝘥: /hq card|month|year|cvv
[娘] 𝘚𝘵𝘢𝘵𝘶𝘴: On ✅
[娘] 𝘎𝘢𝘵𝘦𝘸𝘢𝘺: Shopify + Payezzy

[娘] 𝘕𝘢𝘮𝘦: Obito
[娘] 𝘛𝘺𝘱𝘦: Premium
[娘] 𝘊𝘰𝘮𝘮𝘢𝘯𝘥: /ob card|month|year|cvv
[娘] 𝘚𝘵𝘢𝘵𝘶𝘴: On ✅
[娘] 𝘎𝘢𝘵𝘦𝘸𝘢𝘺: Shopify + Braintree

[娘] 𝘕𝘢𝘮𝘦: Sasori
[娘] 𝘛𝘺𝘱𝘦: Premium
[娘] 𝘊𝘰𝘮𝘮𝘢𝘯𝘥: /sa card|month|year|cvv
[娘] 𝘚𝘵𝘢𝘵𝘶𝘴: On ✅
[娘] 𝘎𝘢𝘵𝘦𝘸𝘢𝘺: Shopify + Paypal

[娘] 𝘕𝘢𝘮𝘦: Ozzy
[娘] 𝘛𝘺𝘱𝘦: Premium
[娘] 𝘊𝘰𝘮𝘮𝘢𝘯𝘥: /oz card|month|year|cvv
[娘] 𝘚𝘵𝘢𝘵𝘶𝘴: On ✅
[娘] 𝘎𝘢𝘵𝘦𝘸𝘢𝘺: Shopify + Eway

[娘] 𝘕𝘢𝘮𝘦: Rinegan
[娘] 𝘛𝘺𝘱𝘦: Premium
[娘] 𝘊𝘰𝘮𝘮𝘢𝘯𝘥: /ri card|month|year|cvv
[娘] 𝘚𝘵𝘢𝘵𝘶𝘴: On ✅
[娘] 𝘎𝘢𝘵𝘦𝘸𝘢𝘺: Shopify CCN

[娘] 𝘕𝘢𝘮𝘦: Tobi
[娘] 𝘛𝘺𝘱𝘦: Premium
[娘] 𝘊𝘰𝘮𝘮𝘢𝘯𝘥: /to card|month|year|cvv
[娘] 𝘚𝘵𝘢𝘵𝘶𝘴: On ✅
[娘] 𝘎𝘢𝘵𝘦𝘸𝘢𝘺: Shopify + Adyen
𝘿𝙚𝙫: @rundilundlegamera"""
buttons_specials_page_1 = InlineKeyboardMarkup(
    [
        [InlineKeyboardButton("𝙍𝙚𝙩𝙪𝙧𝙣 🔄", "home")],
    ]
)

# TOOLS
text_tools = f"""
𝙏𝙤𝙤𝙡𝙨 🛠

[娘] 𝘕𝘢𝘮𝘦: BIN
[娘] 𝘊𝘰𝘮𝘮𝘢𝘯𝘥: /bin card|month|year|cvv
[娘] 𝘚𝘵𝘢𝘵𝘶𝘴: On ✅
[娘] 𝘛𝘺𝘱𝘦: Free

[娘] 𝘕𝘢𝘮𝘦: Reference
[娘] 𝘊𝘰𝘮𝘮𝘢𝘯𝘥: /refe message
[娘] 𝘚𝘵𝘢𝘵𝘶𝘴: On ✅
[娘] 𝘛𝘺𝘱𝘦: Free

[娘] 𝘕𝘢𝘮𝘦: Chat GPT
[娘] 𝘊𝘰𝘮𝘮𝘢𝘯𝘥: /gpt prompt
[娘] 𝘚𝘵𝘢𝘵𝘶𝘴: On ✅
[娘] 𝘛𝘺𝘱𝘦: Premium

[娘] 𝘕𝘢𝘮𝘦: Address
[娘] 𝘊𝘰𝘮𝘮𝘢𝘯𝘥: /rnd country
[娘] 𝘚𝘵𝘢𝘵𝘶𝘴: On ✅
[娘] 𝘛𝘺𝘱𝘦: Free

[娘] 𝘕𝘢𝘮𝘦: SK Checker
[娘] 𝘊𝘰𝘮𝘮𝘢𝘯𝘥: /sk
[娘] 𝘚𝘵𝘢𝘵𝘶𝘴: On ✅
[娘] 𝘛𝘺𝘱𝘦: Free

[娘] 𝘕𝘢𝘮𝘦: GBin
[娘] 𝘊𝘰𝘮𝘮𝘢𝘯𝘥: /gbin bin
[娘] 𝘚𝘵𝘢𝘵𝘶𝘴: On ✅
[娘] 𝘛𝘺𝘱𝘦: Free

[娘] 𝘕𝘢𝘮𝘦: CC Gen
[娘] 𝘊𝘰𝘮𝘮𝘢𝘯𝘥: /gen bin|month|year|rnd
[娘] 𝘚𝘵𝘢𝘵𝘶𝘴: On ✅
[娘] 𝘛𝘺𝘱𝘦: Free

[娘] 𝘕𝘢𝘮𝘦: Info
[娘] 𝘊𝘰𝘮𝘮𝘢𝘯𝘥: /info or /my user
[娘] 𝘚𝘵𝘢𝘵𝘶𝘴: On ✅
[娘] 𝘛𝘺𝘱𝘦: Free

[娘] 𝘕𝘢𝘮𝘦: Plan
[娘] 𝘊𝘰𝘮𝘮𝘢𝘯𝘥: /plan
[娘] 𝘚𝘵𝘢𝘵𝘶𝘴: On ✅
[娘] 𝘛𝘺𝘱𝘦: Free

[娘] 𝘕𝘢𝘮𝘦: Plan Group
[娘] 𝘊𝘰𝘮𝘮𝘢𝘯𝘥: /plang
[娘] 𝘚𝘵𝘢𝘵𝘶𝘴: On ✅
[娘] 𝘛𝘺𝘱𝘦: Free

𝘿𝙚𝙫: @rundilundlegamera"""