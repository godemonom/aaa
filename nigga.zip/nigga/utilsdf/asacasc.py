#!/usr/bin/env python3
currentDate_ = date("Y-m-d")
rank_ = "FREE"
expiryDate_ = "0"
if php_strpos(message_, "/bin") == 0(php_strpos(message_, "!bin") == 0)(php_strpos(message_, ".bin") == 0):
    bin_ = php_substr(message_, 5)
    bin_ = php_substr(bin_, 0, 6)
    ch_ = curl_init()
    curl_setopt(ch_, CURLOPT_URL, "https://lookup.binlist.net/" + bin_)
    curl_setopt(ch_, CURLOPT_USERAGENT, PHP_SERVER["HTTP_USER_AGENT"])
    curl_setopt(ch_, CURLOPT_HTTPHEADER, Array("Host: lookup.binlist.net", "Cookie: _ga=GA1.2.549903363.1545240628; _gid=GA1.2.82939664.1545240628", "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8"))
    curl_setopt(ch_, CURLOPT_FOLLOWLOCATION, 1)
    curl_setopt(ch_, CURLOPT_RETURNTRANSFER, 1)
    fim_ = curl_exec(ch_)
    bank_ = GetStr(fim_, "\"bank\":{\"name\":\"", "\"")
    name_ = php_strtoupper(GetStr(fim_, "\"name\":\"", "\""))
    brand_ = php_strtoupper(GetStr(fim_, "\"brand\":\"", "\""))
    country_ = php_strtoupper(GetStr(fim_, "\"country\":{\"name\":\"", "\""))
    scheme_ = php_strtoupper(GetStr(fim_, "\"scheme\":\"", "\""))
    emoji_ = GetStr(fim_, "\"emoji\":\"", "\"")
    type_ = php_strtoupper(GetStr(fim_, "\"type\":\"", "\""))
    if php_empty(lambda : bank_):
        lookup_ = "<b>Lookup Failed â</b>"
        sendMessage(chatId_, str("<b>") + str(lookup_) + str("%0A%0ABin : ") + str(bin_) + str("</b>"), message_id_)
        sys.exit(0)
    else:
        lookup_ = "<b>ç« BIN INFORMATIONâ»ï¸</b>"
        sendMessage(chatId_, str("<b>") + str(lookup_) + str("%0Aâââââââââââââââââââ%0Aâ¢âBIN : <code>") + str(bin_) + str("</code>%0Aâ¢âINFO : <code>") + str(scheme_) + str("</code>%0Aâ¢âTYPE: <code>") + str(type_) + str("</code>%0Aâ¢âBRAND : <code>") + str(brand_) + str("</code>%0Aâ¢âBANK : <code>") + str(bank_) + str("</code>%0Aâ¢âCOUNTRY : <code>") + str(name_) + str("</code> ") + str(emoji_) + str("%0Aâââââââââââââââââââ%0Aâ¢âCHECKED BY : @") + str(username_) + str(" <code>[") + str(rank_) + str("]</code>%0Aâ¢âDev :<code>@BADDOOR</code></b>"), message_id_)
    # end if
# end if
